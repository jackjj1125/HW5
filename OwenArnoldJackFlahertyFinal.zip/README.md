# HW5
Goals for Checkpoint 1:
* Game board builds and displays
* Player can move around the Board
* Obstacles are generated on Board
* Button to quit the game
* Text Labels for UI
